#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
luajit20_dis.py — LuaJIT 2.0 字节码(.luac) 反汇编器
基于 LuaJIT 2.0.5 官方源码逻辑移植 (lj_bcread.c / lj_bc.h / jit/bc.lua)
用法: python3 luajit20_dis.py <file.luac> [file2.luac ...]
输出: 函数清单 + 每条指令的 op/操作数/常量注释
"""

import sys, struct

# ---------- 从 lj_bc.h BCDEF 生成指令表 ----------
# (name, filler, Amode, Bmode, Cmode-or-Dmode, metamethod)
BCDEF_RAW = [
    ("ISLT","var","___","var","lt"), ("ISGE","var","___","var","lt"),
    ("ISLE","var","___","var","le"), ("ISGT","var","___","var","le"),
    ("ISEQV","var","___","var","eq"), ("ISNEV","var","___","var","eq"),
    ("ISEQS","var","___","str","eq"), ("ISNES","var","___","str","eq"),
    ("ISEQN","var","___","num","eq"), ("ISNEN","var","___","num","eq"),
    ("ISEQP","var","___","pri","eq"), ("ISNEP","var","___","pri","eq"),
    ("ISTC","dst","___","var","___"), ("ISFC","dst","___","var","___"),
    ("IST","___","___","var","___"), ("ISF","___","___","var","___"),
    ("MOV","dst","___","var","___"), ("NOT","dst","___","var","___"),
    ("UNM","dst","___","var","unm"), ("LEN","dst","___","var","len"),
    ("ADDVN","dst","var","num","add"), ("SUBVN","dst","var","num","sub"),
    ("MULVN","dst","var","num","mul"), ("DIVVN","dst","var","num","div"),
    ("MODVN","dst","var","num","mod"),
    ("ADDNV","dst","var","num","add"), ("SUBNV","dst","var","num","sub"),
    ("MULNV","dst","var","num","mul"), ("DIVNV","dst","var","num","div"),
    ("MODNV","dst","var","num","mod"),
    ("ADDVV","dst","var","var","add"), ("SUBVV","dst","var","var","sub"),
    ("MULVV","dst","var","var","mul"), ("DIVVV","dst","var","var","div"),
    ("MODVV","dst","var","var","mod"),
    ("POW","dst","var","var","pow"), ("CAT","dst","rbase","rbase","concat"),
    ("KSTR","dst","___","str","___"), ("KCDATA","dst","___","cdata","___"),
    ("KSHORT","dst","___","lits","___"), ("KNUM","dst","___","num","___"),
    ("KPRI","dst","___","pri","___"), ("KNIL","base","___","base","___"),
    ("UGET","dst","___","uv","___"), ("USETV","uv","___","var","___"),
    ("USETS","uv","___","str","___"), ("USETN","uv","___","num","___"),
    ("USETP","uv","___","pri","___"), ("UCLO","rbase","___","jump","___"),
    ("FNEW","dst","___","func","gc"),
    ("TNEW","dst","___","lit","gc"), ("TDUP","dst","___","tab","gc"),
    ("GGET","dst","___","str","index"), ("GSET","var","___","str","newindex"),
    ("TGETV","dst","var","var","index"), ("TGETS","dst","var","str","index"),
    ("TGETB","dst","var","lit","index"), ("TSETV","var","var","var","newindex"),
    ("TSETS","var","var","str","newindex"), ("TSETB","var","var","lit","newindex"),
    ("TSETM","base","___","num","newindex"),
    ("CALLM","base","lit","lit","call"), ("CALL","base","lit","lit","call"),
    ("CALLMT","base","___","lit","call"), ("CALLT","base","___","lit","call"),
    ("ITERC","base","lit","lit","call"), ("ITERN","base","lit","lit","call"),
    ("VARG","base","lit","lit","___"), ("ISNEXT","base","___","jump","___"),
    ("RETM","base","___","lit","___"), ("RET","rbase","___","lit","___"),
    ("RET0","rbase","___","lit","___"), ("RET1","rbase","___","lit","___"),
    ("FORI","base","___","jump","___"), ("JFORI","base","___","jump","___"),
    ("FORL","base","___","jump","___"), ("IFORL","base","___","jump","___"),
    ("JFORL","base","___","lit","___"),
    ("ITERL","base","___","jump","___"), ("IITERL","base","___","jump","___"),
    ("JITERL","base","___","lit","___"),
    ("LOOP","rbase","___","jump","___"), ("ILOOP","rbase","___","jump","___"),
    ("JLOOP","rbase","___","lit","___"),
    ("JMP","rbase","___","jump","___"),
    ("FUNCF","rbase","___","___","___"), ("IFUNCF","rbase","___","___","___"),
    ("JFUNCF","rbase","___","lit","___"), ("FUNCV","rbase","___","___","___"),
    ("IFUNCV","rbase","___","___","___"), ("JFUNCV","rbase","___","lit","___"),
    ("FUNCC","rbase","___","___","___"), ("FUNCCW","rbase","___","___","___"),
]
OP_NAMES = [r[0] for r in BCDEF_RAW]
OP_MODES = [tuple(r[1:5]) for r in BCDEF_RAW]

BCDUMP_KGC_STR = 5
BCDUMP_KGC_CHILD = 0
BCDUMP_KGC_TAB = 1
BCDUMP_KGC_I64 = 2
BCDUMP_KGC_U64 = 3
BCDUMP_KGC_COMPLEX = 4

BCDUMP_F_BE = 0x01
BCDUMP_F_STRIP = 0x02

PRI_NAMES = {0: "nil", 1: "false", 2: "true", 3: "lightuserdata",
             4: "thread", 5: "proto", 6: "cdata", 7: "table",
             8: "userdata", 9: "function"}

def uleb(data, i):
    v = 0; sh = 0
    while True:
        x = data[i]; i += 1
        v |= (x & 0x7f) << sh
        if x < 0x80:
            break
        sh += 7
    return v, i

def ktabk(data, i):
    """bcread_ktabk: 读一个常量 key/value"""
    tp, i = uleb(data, i)
    if tp >= BCDUMP_KGC_STR:
        l = tp - BCDUMP_KGC_STR
        s = data[i:i+l]; i += l
        return ('str', s), i
    if tp == 3:  # KTAB_INT
        v, i = uleb(data, i)
        return ('int', v), i
    if tp == 4:  # KTAB_NUM
        lo, i = uleb(data, i)
        hi, i = uleb(data, i)
        return ('num', (lo, hi)), i
    return ({0: 'nil', 1: 'false', 2: 'true'}[tp],), i

def ktab(data, i):
    narray, i = uleb(data, i)
    nhash, i = uleb(data, i)
    arr = []
    for _ in range(narray):
        k, i = ktabk(data, i)
        arr.append(k)
    hashes = []
    for _ in range(nhash):
        k, i = ktabk(data, i)
        v, i = ktabk(data, i)
        hashes.append((k, v))
    return ('tab', arr, hashes), i

class Proto:
    __slots__ = ('flags','numparams','framesize','sizeuv','sizekgc','sizekn',
                 'sizebc','ins','uv','kgc','knum','firstline','numline','children','idx','vararg')
    def __init__(self):
        self.children = []

def read_proto(data, i, ln, flags, swap):
    p = Proto()
    end = i + ln
    p.flags = data[i]; i += 1
    p.numparams = data[i]; i += 1
    p.framesize = data[i]; i += 1
    p.sizeuv = data[i]; i += 1
    p.sizekgc, i = uleb(data, i)
    p.sizekn, i = uleb(data, i)
    p.sizebc, i = uleb(data, i); p.sizebc += 1
    p.firstline = 0; p.numline = 0
    if not (flags & BCDUMP_F_STRIP):
        sizedbg, i = uleb(data, i)
        if sizedbg:
            p.firstline, i = uleb(data, i)
            p.numline, i = uleb(data, i)
    # bytecode (第一条 FUNCF/FUNCV 由读侧合成, 文件里只有 sizebc-1 条)
    nins = p.sizebc - 1
    raw = data[i:i+4*nins]; i += 4*nins
    ins = [struct.unpack('<I', raw[k:k+4])[0] for k in range(0, len(raw), 4)]
    if swap:  # 大端
        ins = [struct.unpack('<I', raw[k:k+4][::-1])[0] for k in range(0, len(raw), 4)]
    p.ins = ins
    # upvalues
    uv = data[i:i+2*p.sizeuv]; i += 2*p.sizeuv
    if swap:
        uv = b''.join(uv[k:k+2][::-1] for k in range(0, len(uv), 2))
    p.uv = struct.unpack('<%dH' % p.sizeuv, uv) if p.sizeuv else ()
    # GC 常量
    kgc = []
    for _ in range(p.sizekgc):
        tp, i = uleb(data, i)
        if tp >= BCDUMP_KGC_STR:
            l = tp - BCDUMP_KGC_STR
            s = data[i:i+l]; i += l
            kgc.append(('str', s))
        elif tp == BCDUMP_KGC_CHILD:
            kgc.append(('child',))
        elif tp == BCDUMP_KGC_TAB:
            t, i = ktab(data, i)
            kgc.append(t)
        else:  # I64/U64/COMPLEX
            lo, i = uleb(data, i)
            hi, i = uleb(data, i)
            if tp == BCDUMP_KGC_COMPLEX:
                lo2, i = uleb(data, i); hi2, i = uleb(data, i)
                kgc.append(('cdata','complex', lo, hi, lo2, hi2))
            else:
                kgc.append(('cdata', 'i64' if tp == BCDUMP_KGC_I64 else 'u64', lo, hi))
    p.kgc = kgc
    # number 常量 (uleb128_33: 低 bit 为 isnum)
    knum = []
    for _ in range(p.sizekn):
        b = data[i]; i += 1
        isnum = b & 1
        v = b >> 1
        if v >= 0x40:
            sh = -1
            v &= 0x3f
            while True:
                b = data[i]; i += 1
                sh += 7
                v |= (b & 0x7f) << sh
                if b < 0x80:
                    break
        if isnum:
            hi, i = uleb(data, i)
            knum.append(('num', v, hi))
        else:
            knum.append(('int', v))
    p.knum = knum
    i = end  # 跳过调试信息（STRIP 无；非 STRIP 时 line/var 信息不影响反汇编）
    p.vararg = bool(p.flags & 0x04)
    return p, i

def parse(data):
    assert data[:4] == b'\x1bLJ\x01', '不是 LuaJIT 字节码'
    i = 4
    flags, i = uleb(data, i)
    chunkname = b'=?'
    if not (flags & BCDUMP_F_STRIP):
        ln, i = uleb(data, i)
        chunkname = data[i:i+ln]; i += ln
    swap = bool(flags & BCDUMP_F_BE)
    protos = []
    while True:
        ln, i = uleb(data, i)
        if ln == 0:
            break
        p, i = read_proto(data, i, ln, flags, swap)
        protos.append(p)
    # 按写入顺序(post-order: children 先于 parent)构建树
    unassigned = list(protos)
    def settle(p):
        c = sum(1 for k in p.kgc if k[0] == 'child')
        children = []
        for _ in range(c):
            ch = unassigned.pop()
            children.append(ch)
        children.reverse()
        for ch in children:
            settle(ch)
        p.children = children
    if protos:
        root = unassigned.pop()  # 栈顶 = 最后写入的 root
        settle(root)
    return protos, chunkname, flags

def fmt_const(kgc, knum, d, mode):
    """常量注释。LuaJIT 的 RDC/RD 常量字段按'从尾部数'引用 kgc: idx = len-1-d"""
    if mode == 'str':
        idx = len(kgc) - 1 - d
        if 0 <= idx < len(kgc) and kgc[idx][0] == 'str':
            return 'str[%d]=%s' % (idx, kgc[idx][1].decode('utf-8', 'replace'))
        return 'kgc[%d]' % idx
    if mode == 'num':
        k = knum[d] if 0 <= d < len(knum) else None
        return 'num[%d]=%r' % (d, k)
    if mode == 'lits':
        return 'lit %d' % d
    if mode == 'pri':
        return PRI_NAMES.get(d & 0xff, 'pri?%d' % d)
    if mode == 'uv':
        return 'uv[%d]' % d
    if mode in ('tab', 'func'):
        idx = len(kgc) - 1 - d
        return 'kgc[%d]' % idx
    return None

def dis_proto(p, out, indent, fnidx):
    out.append('%s-- BYTECODE -- fn[%d] size=%d params=%d frame=%d uv=%d vararg=%s' %
               (indent, fnidx, p.sizebc, p.numparams, p.framesize, p.sizeuv, p.vararg))
    targets = set()
    for pc, ins in enumerate(p.ins):
        op = ins & 0xff
        if op < len(OP_MODES) and OP_MODES[op][2] == 'jump':
            d = (ins >> 16) & 0xffff
            tgt = pc + d - 0x8000
            targets.add(tgt)
    for pc, ins in enumerate(p.ins):
        op = ins & 0xff
        if op >= len(OP_NAMES):
            out.append('%s%04d  ??? op=%d ins=0x%08x' % (indent, pc+1, op, ins))
            continue
        name = OP_NAMES[op]
        ma, mb, mc, mt = OP_MODES[op]
        a = (ins >> 8) & 0xff
        c = (ins >> 16) & 0xff
        b = (ins >> 24) & 0xff
        d = (ins >> 16) & 0xffff
        arrow = '=>' if pc in targets else '  '
        fields = ''
        note = ''
        if mc == 'jump':
            tgt = pc + d - 0x8000
            fields = '%3d' % (d - 0x8000)
            note = '=> %d' % (tgt + 1)
            if ma != '___':
                fields = '%3d %s' % (a, fields)
        elif mb != '___':
            fields = '%3d %3d' % (b, c)
            if ma != '___':
                fields = '%3d %s' % (a, fields)
            if mc == 'str':
                note = fmt_const(p.kgc, p.knum, c, 'str')
            elif mc == 'num':
                note = fmt_const(p.kgc, p.knum, c, 'num')
        else:
            if ma != '___':
                fields = '%3d' % a
            if mc == 'str':
                note = fmt_const(p.kgc, p.knum, d, 'str')
            elif mc == 'num':
                note = fmt_const(p.kgc, p.knum, d, 'num')
            elif mc == 'lits':
                v = d if d <= 32767 else d - 65536
                note = 'lit %d' % v
            elif mc == 'pri':
                note = PRI_NAMES.get(d & 0xff, 'pri?%d' % d)
            elif mc == 'uv':
                note = 'uv[%d]' % d
            elif mc in ('tab', 'func'):
                note = fmt_const(p.kgc, p.knum, d, 'func')
        if note:
            out.append('%s%04d %s %-7s %-12s ; %s' % (indent, pc+1, arrow, name, fields, note))
        else:
            out.append('%s%04d %s %-7s %-12s' % (indent, pc+1, arrow, name, fields))
    out.append('')
    for ch in p.children:
        dis_proto(ch, out, indent + '    ', fnidx + 1)

def main():
    if len(sys.argv) < 2:
        print('usage: luajit20_dis.py <file.luac> ...')
        sys.exit(1)
    for path in sys.argv[1:]:
        data = open(path, 'rb').read()
        try:
            protos, chunkname, flags = parse(data)
        except Exception as e:
            print('== %s: 解析失败: %s' % (path, e))
            continue
        print('=' * 20, path, 'size=%d' % len(data),
              'strip=%s' % bool(flags & BCDUMP_F_STRIP),
              'chunk=%r' % chunkname)
        out = []
        if protos:
            dis_proto(protos[-1], out, '', 0)
        print('\n'.join(out))

if __name__ == '__main__':
    main()
