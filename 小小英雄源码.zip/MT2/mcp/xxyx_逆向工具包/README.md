# 小小英雄(.luac) 逆向工具包

提取自《小小英雄 4399 版》(com.sy4399.yxzb) 的逆向工程，2026-10-19

## 内容
- `luajit20_dis.py`  主工具：LuaJIT 2.0 字节码(.luac) 反汇编器（纯 Python 实现，无依赖）
- `samples/network.luac`   游戏 network.lua 的字节码样本
- `samples/network_dis样例.txt`  反汇编输出样例

## 用法
```bash
python3 luajit20_dis.py samples/network.luac
# 或批量
python3 luajit20_dis.py *.luac
```

## 游戏字节码格式要点
- 文件头：`1b 4c 4a 01`（\x1bLJ + BCDUMP_VERSION=1，即 LuaJIT 2.0 格式）
- 本包内脚本为 STRIP 模式（无调试信息/无 chunk 名），但字符串常量完整保留
- 指令布局（32 位小端）：op=低 8 位（6 位有效）, A=次字节, C=字节2, B=字节3（跳转等 D=B<<8|C 的 16 位，偏移 = D-0x8000）
- 常量引用为"从尾部数"：有效 kgc 索引 = len(kgc)-1-D（GGET/KSTR/FNEW/TSETS 等）
- 嵌套函数：字节流按后序写入（children 先于 parent），读取时用栈弹出配对

## 为什么不用官方 luajit -bl
- 游戏字节码为 LuaJIT 2.0 格式；LuaJIT 2.1（arm64 可编译版）拒绝加载 v1 字节码（FR2 布局不兼容）
- LuaJIT 2.0 本身不支持 arm64 编译 → 用纯 Python 移植官方解析逻辑，全平台可用

## 下一步（路线 A：mock 网络进主城）
1. 反汇编 lua_logic/game.luac、lua_common/define.luac、protocal.luac 等，画启动流程图
2. 确认 C# 侧 LuaScriptLoader 加载链路（Assembly-CSharp-firstpass.dll）
3. 方案：改 lua bundle 中的 network.lua（Lua 明文/新 bc 均可被加载器识别）→ mock 登录
4. 重打包 + debug 签名
